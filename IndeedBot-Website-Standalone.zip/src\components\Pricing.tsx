"use client";

import { motion } from "framer-motion";
import { Check, ShieldCheck, Zap } from "lucide-react";

export const Pricing = () => {
    return (
        <section id="pricing" className="py-32 px-4 bg-[#f3f2f1] relative">
            <div className="max-w-5xl mx-auto text-center">
                <h2 className="text-4xl md:text-5xl font-black mb-6 text-[#2d2d2d] uppercase tracking-tighter italic">Operational <span className="text-primary not-italic">Licensing.</span></h2>
                <p className="text-neutral-600 mb-16 max-w-xl mx-auto text-lg font-medium">
                    Strategic access for high-stakes professionals. Institutional-grade career intelligence infrastructure.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="bg-white p-12 rounded-[2rem] border border-neutral-200 text-left shadow-sm hover:shadow-xl transition-shadow"
                    >
                        <h3 className="text-2xl font-black mb-2 text-[#2d2d2d] uppercase italic">Individual Intelligence License</h3>
                        <div className="flex items-baseline gap-1 mb-8">
                            <span className="text-4xl font-black text-[#2d2d2d]">$29</span>
                            <span className="text-neutral-400 font-bold uppercase text-[10px] tracking-widest">/ Operational Month</span>
                        </div>

                        <ul className="space-y-4 mb-10">
                            {["Market Intelligence Access", "50 Strategic Opportunity Scans", "Encrypted Job Vault", "Candidate Positioning Module"].map((item, i) => (
                                <li key={i} className="flex items-center gap-3 text-neutral-600 font-medium text-sm">
                                    <Check className="w-5 h-5 text-green-500" />
                                    <span>{item}</span>
                                </li>
                            ))}
                        </ul>

                        <button className="w-full py-4 rounded-xl border-2 border-primary text-primary font-black hover:bg-primary/5 transition-all text-xs uppercase tracking-widest">
                            Provision License
                        </button>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        className="bg-white p-12 rounded-[2rem] border-2 border-primary text-left shadow-2xl relative overflow-hidden"
                    >
                        <div className="absolute top-0 right-0 bg-primary px-6 py-2 text-[10px] font-black uppercase tracking-widest text-white rounded-bl-xl shadow-lg">
                            PRIORITY INFRASTRUCTURE
                        </div>

                        <h3 className="text-2xl font-black mb-2 text-[#2d2d2d] uppercase italic">Strategic Intelligence Suite</h3>
                        <div className="flex items-baseline gap-1 mb-8">
                            <span className="text-4xl font-black text-primary">$79</span>
                            <span className="text-neutral-400 font-bold uppercase text-[10px] tracking-widest">/ Operational Month</span>
                        </div>

                        <ul className="space-y-4 mb-10">
                            {["Full Multi-Agent Swarm Access", "Unlimited Strategic Scans", "Risk & Signal Engine Access", "Priority Reasoning Compute", "Advanced Simulation Credits"].map((item, i) => (
                                <li key={i} className="flex items-center gap-3 text-[#2d2d2d] font-bold text-sm">
                                    <div className="bg-primary/10 p-1 rounded">
                                        <Check className="w-4 h-4 text-primary" />
                                    </div>
                                    <span>{item}</span>
                                </li>
                            ))}
                        </ul>

                        <button className="w-full py-4 rounded-xl bg-primary text-white font-black hover:bg-indeed-blue-hover hover:scale-[1.02] transition-all text-xs uppercase tracking-widest shadow-xl shadow-primary/30">
                            Secure Enterprise Suite
                        </button>
                    </motion.div>
                </div>

                <div className="mt-16 p-8 border border-neutral-200 rounded-3xl bg-neutral-100 flex flex-col md:flex-row items-center justify-between gap-8 mb-12">
                    <div className="text-left">
                        <h4 className="text-xl font-black italic uppercase text-[#2d2d2d]">Enterprise & Institutional Licensing</h4>
                        <p className="text-sm text-neutral-500 font-medium">For CTOs, HR Leaders, and professional career management institutions.</p>
                    </div>
                    <button className="px-8 py-3 bg-[#2d2d2d] text-white font-black text-xs uppercase tracking-widest rounded-xl hover:bg-black transition-all">
                        Request Quote
                    </button>
                </div>

                <p className="text-sm text-neutral-400 font-medium">
                    <span className="text-primary font-bold">LEGACY ACCESS:</span> Standard tier available for early adopters. Protocol v4.0.0.
                </p>
            </div>
        </section>
    );
};
