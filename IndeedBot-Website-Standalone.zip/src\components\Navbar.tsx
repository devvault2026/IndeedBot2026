"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

export const Navbar = () => {
    return (
        <motion.nav
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-4 bg-white/80 backdrop-blur-md border-b border-neutral-200"
        >
            <div className="flex items-center gap-2">
                <Link href="/" className="flex items-center gap-2">
                    <img
                        src="https://res.cloudinary.com/dpfapm0tl/image/upload/v1770163492/icon_x6kgnr.png"
                        alt="IndeedBot Logo"
                        className="w-10 h-10 object-contain"
                    />
                    <span className="text-xl font-bold tracking-tight text-[#2d2d2d]">
                        Indeed<span className="text-primary font-black">Bot</span>
                        <span className="ml-1 text-[10px] bg-neutral-100 px-1.5 py-0.5 rounded text-neutral-500 font-bold uppercase tracking-widest leading-none">2026</span>
                    </span>
                </Link>
            </div>

            <div className="hidden md:flex items-center gap-10 text-neutral-600 font-semibold text-sm">
                <div className="group relative">
                    <button className="flex items-center gap-1 hover:text-primary transition-colors cursor-pointer py-2">
                        FEATURES <ChevronDown className="w-4 h-4" />
                    </button>
                    <div className="absolute top-full left-0 w-64 bg-white border border-neutral-200 shadow-2xl rounded-2xl py-4 flex flex-col gap-1 opacity-0 translate-y-2 pointer-events-none group-hover:opacity-100 group-hover:translate-y-0 group-hover:pointer-events-auto transition-all">
                        <Link href="/features/intelligence" className="px-6 py-2 hover:bg-neutral-50 hover:text-primary transition-colors">Career Intelligence</Link>
                        <Link href="/features/resume" className="px-6 py-2 hover:bg-neutral-50 hover:text-primary transition-colors">Resume Architect</Link>
                        <Link href="/features/scout" className="px-6 py-2 hover:bg-neutral-50 hover:text-primary transition-colors">Corporate Scout</Link>
                        <Link href="/features/vault" className="px-6 py-2 hover:bg-neutral-50 hover:text-primary transition-colors">Job Vault</Link>
                        <Link href="/features/interview" className="px-6 py-2 hover:bg-neutral-50 hover:text-primary transition-colors">Interview Coach</Link>
                    </div>
                </div>
                <Link href="/pricing" className="hover:text-primary transition-colors">PRICING</Link>
                <Link href="/docs" className="hover:text-primary transition-colors">DOCUMENTATION</Link>
            </div>

            <div className="flex items-center gap-4">
                <button className="hidden sm:block text-sm font-bold text-primary hover:underline">
                    Sign In
                </button>
                <button className="px-6 py-2.5 bg-primary text-white font-bold rounded-lg hover:bg-indeed-blue-hover transition-all active:scale-95 shadow-md shadow-primary/20">
                    DEPLOY NOW
                </button>
            </div>
        </motion.nav>
    );
};
